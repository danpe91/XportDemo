# Cookbook:: opsworks-audit
# Recipe:: default

include_recipe 'audit::default'
